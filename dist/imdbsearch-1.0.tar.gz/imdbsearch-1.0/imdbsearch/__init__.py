# code that will run during initialization of the package itself
# or just to tell Python that directory contains a package